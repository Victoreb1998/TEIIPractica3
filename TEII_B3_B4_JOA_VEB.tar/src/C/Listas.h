// Archivo de cabecera con prototipos de funciones del módulo implementado en C.


// Función de eliminación de elementos iguales en una lista en C. Trabaja en memoria ya reservada 
// por Python.
int* Listas(int * lista, // Lista original
	const int size, // Longitud 
	int * longitudFinal); // Longitud final de la lista
